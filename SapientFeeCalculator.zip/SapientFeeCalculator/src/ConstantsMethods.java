import java.text.SimpleDateFormat;
import java.util.Date;

public class ConstantsMethods 
{
		private int CSV = 1;
		private int TXT = 2;
		private int XML = 3;
		
		public int getCSV() {
			return CSV;
		}
		public void setCSV(int cSV) {
			CSV = cSV;
		}
		public int getTXT() {
			return TXT;
		}
		public void setTXT(int tXT) {
			TXT = tXT;
		}
		public int getXML() {
			return XML;
		}
		public void setXML(int xML) {
			XML = xML;
		}
		

	/*
	 * Define Fees for Transaction.
	 */
		
		private double FIVE_HUNDREAD = 500;
		private double HUNDREAD = 100;
		private double FIFTY = 50;
		private double TEN = 10;
		public double getFIVE_HUNDREAD() {
			return FIVE_HUNDREAD;
		}
		public void setFIVE_HUNDREAD(double fIVE_HUNDREAD) {
			FIVE_HUNDREAD = fIVE_HUNDREAD;
		}
		public double getHUNDREAD() {
			return HUNDREAD;
		}
		public void setHUNDREAD(double hUNDREAD) {
			HUNDREAD = hUNDREAD;
		}
		public double getFIFTY() {
			return FIFTY;
		}
		public void setFIFTY(double fIFTY) {
			FIFTY = fIFTY;
		}
		public double getTEN() {
			return TEN;
		}
		public void setTEN(double tEN) {
			TEN = tEN;
		}
	
	
	class TransactionType
	{
		private int BUY_1 = 1;
		private String BUY = "BUY";
		private int SELL_2 = 2;
		private String SELL = "SELL";
		private int DEPOSIT_3 = 3;
		private String DEPOSIT = "DEPOSIT";
		private int WITHDRAW_4 = 4;
		private String WITHDRAW = "WITHDRAW";
		public int getBUY_1() {
			return BUY_1;
		}
		public void setBUY_1(int bUY_1) {
			BUY_1 = bUY_1;
		}
		public String getBUY() {
			return BUY;
		}
		public void setBUY(String bUY) {
			BUY = bUY;
		}
		public int getSELL_2() {
			return SELL_2;
		}
		public void setSELL_2(int sELL_2) {
			SELL_2 = sELL_2;
		}
		public String getSELL() {
			return SELL;
		}
		public void setSELL(String sELL) {
			SELL = sELL;
		}
		public int getDEPOSIT_3() {
			return DEPOSIT_3;
		}
		public void setDEPOSIT_3(int dEPOSIT_3) {
			DEPOSIT_3 = dEPOSIT_3;
		}
		public String getDEPOSIT() {
			return DEPOSIT;
		}
		public void setDEPOSIT(String dEPOSIT) {
			DEPOSIT = dEPOSIT;
		}
		public int getWITHDRAW_4() {
			return WITHDRAW_4;
		}
		public void setWITHDRAW_4(int wITHDRAW_4) {
			WITHDRAW_4 = wITHDRAW_4;
		}
		public String getWITHDRAW() {
			return WITHDRAW;
		}
		public void setWITHDRAW(String wITHDRAW) {
			WITHDRAW = wITHDRAW;
		}
	}
	
	public static Double parseMarketValue(String marketValue)
	{
		try
		{
			return Double.parseDouble(marketValue);
		}
		catch(Exception ex)
		{
			return (double) 0;
		}
	}

	public static Boolean getPriority(String priority)
	{
		if(priority!= null)
		{
			priority = priority.trim();
			if(priority.equals("Y")||priority.equals("y"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}

	public static Date parseDate(String date)
	{
		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Date convertedCurrentDate = sdf.parse(date);
			System.out.println(convertedCurrentDate);
			return convertedCurrentDate;
		}
		catch(Exception  ex)
		{
			return null;
		}
	}

	public static Integer parseTransactionType(String type)
	{
		ConstantsMethods cs = new ConstantsMethods();
		TransactionType ty = cs.new TransactionType();
		if(type.equals("BUY"))
		{
			return ty.BUY_1;
		}
		if(type.equals("SELL"))
		{
			return ty.SELL_2;
		}if(type.equals("DEPOSIT"))
		{
			return ty.DEPOSIT_3;
		}
		if(type.equals("WITHDRAW"))
		{
			return ty.WITHDRAW_4;
		}
		return null;
	}

	public static String getTypeName(Integer typeName)
	{
		ConstantsMethods cs = new ConstantsMethods();
		TransactionType ty = cs.new TransactionType();
		if(typeName==ty.BUY_1)
		{
			return ty.BUY + "\t";
		}
		else if(typeName==ty.SELL_2)
		{
			return ty.SELL + "\t";
		}
		else if(typeName==ty.DEPOSIT_3)
		{
			return ty.DEPOSIT+ "\t";
		}
		else if(typeName==ty.WITHDRAW_4)
		{
			return ty.WITHDRAW + "\t";
		}
		return null;
	}
	
}