import java.io.File;

public class TransactionReader {
	
	private static TransactionReader transactionReader;

	private static CsvTransactionReader csvTransactionReader;

	public static TransactionReader getTrasactionReaderInstance()
	{
		if (null == transactionReader)
		{
			synchronized (TransactionReader.class)
			{
				if (null == transactionReader)
				{
					transactionReader = new TransactionReader();
					csvTransactionReader= new CsvTransactionReader();
				}
			}
		}
		return transactionReader;
	}

	/**
	 * 
	 * @return
	 */
	public CsvTransactionReader readCsvFile(){
		return csvTransactionReader;
	}

	/**
	 * 
	 * @param fileType
	 * @return
	 */
	public CsvTransactionReader readFile(String fileType1,File transactionFile) {
		switch (fileType1) {
		case "CSV":
			CsvTransactionReader.readTransaction(transactionFile);
			return csvTransactionReader;
		//case TEXT:
		//case XML:
		default:
			return null;
		}
	}



}
