import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CalculateTransaction {

	public List<TransactionInput> transactionList;

	

	/**
	 * This method will save the transaction into list.
	 * later on in database.
	 * @param transaction
	 */
	public void saveTransaction(TransactionInput transaction){

		if(transactionList==null){
			transactionList = new ArrayList<TransactionInput>();
		}

		transactionList.add(calculateTransactionFee(transaction));

	}

	/**
	 * This method will be update the fee according to transaction.
	 * @param transaction
	 */
	private TransactionInput calculateTransactionFee(TransactionInput transaction) {
		ConstantsMethods cm = new ConstantsMethods();
		if(isIntradayTransaction(transaction)){
			transaction.setTransactionFees(cm.getTEN());
		} else {

			if(transaction.getPriority()){
				transaction.setTransactionFees(cm.getFIVE_HUNDREAD());

			} else{				
				if(transaction.getTransactionType() == cm.parseTransactionType("SELL") ||
						transaction.getTransactionType() == cm.parseTransactionType("WITHDRAW")){

					transaction.setTransactionFees(cm.getHUNDREAD());

				} else if(transaction.getTransactionType() == cm.parseTransactionType("BUY")||
						transaction.getTransactionType() == cm.parseTransactionType("DEPOSIT")){

					transaction.setTransactionFees(cm.getFIFTY());			
				}

			}

		}
		return transaction;
	}

	/**
	 * This method cheack weather transction is IntraDay or not.
	 * @param transaction
	 * @return
	 */
	private boolean isIntradayTransaction(TransactionInput transaction) {
		boolean isIntraDayTransaction= false;
		TransactionInput temp = null;
		if(transactionList.size() > 0 ){
			for (TransactionInput trans : transactionList) {
				if(trans.getClientId().equals(transaction.getClientId())&&
						trans.getSecurityId().equals(transaction.getSecurityId()) &&
						trans.getTransactionDate().equals(transaction.getTransactionDate())){
					if((trans.getTransactionType()==ConstantsMethods.parseTransactionType("BUY") && 
							transaction.getTransactionType()==ConstantsMethods.parseTransactionType("SELL")) ||
							(trans.getTransactionType()==ConstantsMethods.parseTransactionType("DEPOSIT") && 
							transaction.getTransactionType()==ConstantsMethods.parseTransactionType("WITHDRAW"))){
						isIntraDayTransaction= true;
						temp= trans;						
						break;
					}
				}

			}

			if(temp!=null){
				transactionList.remove(temp);
				ConstantsMethods cm = new ConstantsMethods();
				temp.setTransactionFees(cm.getTEN());
				transactionList.add(temp);
			}

		} else {
			isIntraDayTransaction= false;
		}

		return isIntraDayTransaction;
	}

	/**
	 * 
	 * @param transactionAttributes
	 * @return
	 */
	public TransactionInput getTransaction(String[] transactionAttributes) {	
		for (String string : transactionAttributes) {
			System.out.print(" "+string);
		}
		TransactionInput transaction = new TransactionInput();
		transaction.setExternalTransactionID(transactionAttributes[0]);
		transaction.setClientId(transactionAttributes[1]);
		transaction.setSecurityId(transactionAttributes[2]);
		transaction.setTransactionType(ConstantsMethods.parseTransactionType(transactionAttributes[3]));
		transaction.setTransactionDate(ConstantsMethods.parseDate(transactionAttributes[4]));
		transaction.setMarketValue(ConstantsMethods.parseMarketValue(transactionAttributes[5]));
		transaction.setPriority(ConstantsMethods.getPriority(transactionAttributes[6]));
		return transaction;
	}

	/**
	 * This method will be display TransactionReport.
	 */
	public void displayTransactionReport(){
		System.out.println("Calculated Fees:-");
		System.out.println("--------------------------------------------------------------------------------");
		System.out.println("Client Id | Transaction Type | Transaction Date | Priority | Processing Fee    |");
		for (TransactionInput transaction : transactionList) {
			System.out.println("--------------------------------------------------------------------------------");
			System.out.println(transaction.getClientId()+"\t| "+ConstantsMethods.getTypeName(transaction.getTransactionType())+"\t| "+
					transaction.getTransactionDate()+"\t| "+(transaction.getPriority()?"HIGH\t":"NORMAL")+ "\t| "+
					transaction.getTransactionFees()+"\t|");
		}
		System.out.println("--------------------------------------------------------------------------------");
	}
}

