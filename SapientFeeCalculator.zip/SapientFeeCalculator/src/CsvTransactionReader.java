import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CsvTransactionReader
{
 
	CalculateTransaction ct = new CalculateTransaction();
public static void readTransaction(File transactionFile) {

		
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = "|";

		try {

			br = new BufferedReader(new FileReader(transactionFile));
			while ((line = br.readLine()) != null) {
				String[] transactionAttributes = line.split(cvsSplitBy);
				CalculateTransaction ct = new CalculateTransaction();
				TransactionInput transaction = ct.getTransaction(transactionAttributes); 
				ct.saveTransaction(transaction);

			}		 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}	
	
	public CsvTransactionReader readFile(String fileType) {
		if(fileType == "CSV"){
			return TransactionReader.getTrasactionReaderInstance().readCsvFile();
		}
		return null;
	}
	
	

}
